function alertMessage()
{
alert("Hello user")
}
